package com.nhai.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Background e chole: "ai sunco" shuney jage, tarpor command shuney kaj kore. */
class AssistantService : Service(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var isRunning = false
        const val ACTION_LISTEN = "com.nhai.app.LISTEN"
        private const val CHANNEL = "nhai_channel"

        // Wake word er variant. canon() diye shoman kore match kora hoy.
        private val WAKE = listOf(
            "aisunco", "aisuncho", "aishunco", "aishuncho", "aisunchho", "hisunco", "aysunco", "eisunco", "eisuncho",
            "isunco", "isuncho", "aisunko", "aysunko", "eyesunco", "eyesuncho", "asuncho",
            "এইশুনছো", "এইশুনছ", "আইশুনছো", "আইশুনছ", "এইসুনছো", "এইশুনছেন", "আইসুনছো", "এআইশুনছো", "এআইশুনছ"
        )
    }

    private enum class Mode { WAKE, COMMAND }

    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var overlay: Overlay? = null
    private var mode = Mode.WAKE
    private var running = false
    private var handled = false
    private var busy = false
    private var offlineFailed = false
    private var startToken = 0
    private var lastEvent = 0L
    private var lastPartialLog = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            startFg()
        } catch (e: Exception) {
            AppLog.add("startForeground failed: $e")
            stopSelf()
            return
        }
        running = true
        isRunning = true
        lastEvent = System.currentTimeMillis()
        tts = TextToSpeech(this, this)
        overlay = Overlay(this) { onOrbTapped() }
        overlay?.showOrb()
        listen(Mode.WAKE, 300, true)
        main.postDelayed(watchdog, 10000)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_LISTEN) {
            main.post { onOrbTapped() }
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
    }

    private fun startFg() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "NH-Ai", NotificationManager.IMPORTANCE_LOW))
        val openPi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val listenIntent = Intent(this, AssistantService::class.java)
        listenIntent.action = ACTION_LISTEN
        val listenPi = PendingIntent.getService(this, 1, listenIntent, PendingIntent.FLAG_IMMUTABLE)
        val action = Notification.Action.Builder(android.R.drawable.ic_btn_speak_now, "🎙 বলো", listenPi).build()
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("NH-Ai চালু আছে")
            .setContentText("বলো: \"ai sunco\" বা নিচের 🎙 বলো বাটন চাপো")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openPi)
            .addAction(action)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- Speech recognition loop ----------
    private fun listen(m: Mode, delayMs: Long, fresh: Boolean = false) {
        val tok = ++startToken
        main.postDelayed({
            if (tok == startToken) startRecognizer(m, fresh)
        }, delayMs)
    }

    private fun makeIntent(m: Mode): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        val offline = !isOnline() || (Prefs.offlineFirst(this) && !offlineFailed)
        val lang = if (offline) Prefs.offlineLang(this) else Prefs.voiceLang(this)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline)
        if (m == Mode.COMMAND) {
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        return i
    }

    private fun startRecognizer(m: Mode, fresh: Boolean) {
        if (!running) return
        mode = m
        handled = false
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            overlay?.showPanel("ERROR", "এই ফোনে speech recognition সার্ভিস নেই। Google অ্যাপ আপডেট করো।")
            return
        }
        val r: SpeechRecognizer
        val existing = sr
        if (existing == null || fresh) {
            releaseSr()
            val created = SpeechRecognizer.createSpeechRecognizer(this)
            created.setRecognitionListener(listener)
            sr = created
            r = created
        } else {
            try { existing.cancel() } catch (e: Exception) { }
            r = existing
        }
        try {
            r.startListening(makeIntent(m))
        } catch (e: Exception) {
            AppLog.add("startListening failed: $e")
            releaseSr()
            listen(m, 1500, true)
        }
        overlay?.setActive(m == Mode.COMMAND)
    }

    private fun stopSr() {
        try { sr?.cancel() } catch (e: Exception) { }
    }

    private fun releaseSr() {
        val r = sr
        sr = null
        if (r != null) {
            try { r.cancel() } catch (e: Exception) { }
            try { r.destroy() } catch (e: Exception) { }
        }
    }

    /** Bangla/English ucchoronger choto fark mushe shoman kore (শ/ষ=স, ছ=চ, sh=s, ch=c, k=c ityadi). */
    private fun canon(s: String): String {
        val sb = StringBuilder()
        for (ch0 in s.lowercase(Locale.ROOT)) {
            if (ch0.isWhitespace() || ch0 in ".,!?-'\"।" || ch0 == 'ঁ') continue
            val ch = when (ch0) {
                'শ', 'ষ' -> 'স'
                'ছ' -> 'চ'
                'ূ' -> 'ু'
                'ী' -> 'ি'
                else -> ch0
            }
            sb.append(ch)
        }
        return sb.toString()
            .replace("sh", "s").replace("chh", "c").replace("ch", "c")
            .replace("oo", "u").replace("ee", "i").replace("k", "c")
    }

    private fun wakeList(): List<String> {
        val custom = Prefs.wakeRaw(this).split(',', '\n').map { canon(it) }.filter { it.length >= 3 }
        return custom + WAKE.map { canon(it) }
    }

    private fun isWake(list: List<String>?): Boolean {
        if (list == null) return false
        val wakes = wakeList()
        val loose = Prefs.looseWake(this)
        for (s in list) {
            val n = canon(s)
            if (wakes.any { n.contains(it) }) return true
            if (loose && (n.contains("সুনচ") || n.contains("sunc"))) return true
        }
        return false
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            if (!busy && mode == Mode.WAKE && System.currentTimeMillis() - lastEvent > 25000) {
                AppLog.add("watchdog: recognizer chup, abar chalu korchi")
                lastEvent = System.currentTimeMillis()
                listen(Mode.WAKE, 0, true)
            }
            main.postDelayed(this, 10000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { lastEvent = System.currentTimeMillis() }
        override fun onBeginningOfSpeech() { lastEvent = System.currentTimeMillis() }
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            lastEvent = System.currentTimeMillis()
            if (!running || handled || busy) return
            if (error == SpeechRecognizer.ERROR_CLIENT) return // amader nijer cancel
            if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) AppLog.add("recognizer error $error")
            if (error == 12 || error == 13) {
                offlineFailed = true
                AppLog.add("speech language/offline pack unavailable ($error)")
                if (!isOnline()) {
                    overlay?.showPanel("OFFLINE", "অফলাইন ভয়েস প্যাক (" + Prefs.offlineLang(this@AssistantService) + ") নেই। Google অ্যাপ > Settings > Voice > Offline speech recognition থেকে ডাউনলোড করো। ততক্ষণ অ্যাপের বক্সে লিখে কমান্ড দাও।")
                    listen(Mode.WAKE, 15000, true)
                    return
                }
            }
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                overlay?.showPanel("ERROR", "মাইক্রোফোন পারমিশন দাও।")
                return
            }
            if (mode == Mode.COMMAND) {
                overlay?.hidePanel()
                overlay?.setActive(false)
                listen(Mode.WAKE, 300)
            } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                listen(Mode.WAKE, 1200, true)
            } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT || error == SpeechRecognizer.ERROR_SERVER) {
                listen(Mode.WAKE, 2000, true)
            } else {
                listen(Mode.WAKE, 100)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            if (mode != Mode.WAKE || handled || busy) return
            val l = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val first = l?.firstOrNull() ?: ""
            if (first.isNotEmpty() && first != lastPartialLog) {
                lastPartialLog = first
                AppLog.add("partial: $first")
            }
            if (isWake(l)) {
                handled = true
                main.post { onWake() }
            }
        }

        override fun onResults(results: Bundle?) {
            lastEvent = System.currentTimeMillis()
            if (!running || handled || busy) return
            val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            AppLog.add("heard[" + mode + "]: " + (l?.firstOrNull() ?: ""))
            if (mode == Mode.WAKE) {
                if (isWake(l)) {
                    handled = true
                    main.post { onWake() }
                } else {
                    listen(Mode.WAKE, 100)
                }
            } else {
                val text = l?.firstOrNull()?.trim() ?: ""
                if (text.isEmpty()) {
                    overlay?.hidePanel()
                    overlay?.setActive(false)
                    listen(Mode.WAKE, 300)
                } else {
                    handled = true
                    process(text)
                }
            }
        }
    }

    // ---------- Flow ----------
    private fun onOrbTapped() {
        if (busy) return
        stopSr()
        handled = true
        onWake()
    }

    private fun onWake() {
        stopSr()
        AppLog.add("WAKE detected")
        try {
            ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150)
        } catch (e: Exception) { }
        overlay?.setActive(true)
        overlay?.showPanel("LISTENING", "বলো, আমি শুনছি...")
        listen(Mode.COMMAND, 450)
    }

    private fun process(text: String) {
        busy = true
        stopSr()
        overlay?.showPanel("THINKING", "তুমি: $text")
        val app = applicationContext
        Thread {
            val reply = try {
                CommandRouter.handle(app, text) ?: if (app.isOnline()) Brain.ask(app, text) else OFFLINE_MSG
            } catch (e: Exception) {
                "একটা সমস্যা হয়েছে, আবার বলো।"
            }
            AppLog.add("cmd: $text -> $reply")
            main.post {
                overlay?.showPanel("NH-AI", reply)
                val followUp = reply.trim().endsWith("?")
                speak(reply) {
                    if (followUp) {
                        busy = false
                        overlay?.setActive(true)
                        listen(Mode.COMMAND, 300)
                    } else {
                        main.postDelayed({
                            overlay?.hidePanel()
                            overlay?.setActive(false)
                            busy = false
                            listen(Mode.WAKE, 200)
                        }, 3000)
                    }
                }
            }
        }.start()
    }

    private fun speak(text: String, done: () -> Unit) {
        val t = tts
        var fired = false
        val fire: () -> Unit = {
            if (!fired) {
                fired = true
                done()
            }
        }
        if (t == null || !ttsReady) {
            main.postDelayed({ fire() }, 2000)
            return
        }
        val bn = text.any { it in '\u0980'..'\u09FF' }
        val lr = t.setLanguage(if (bn) Locale("bn", "BD") else Locale.US)
        if (lr == TextToSpeech.LANG_MISSING_DATA || lr == TextToSpeech.LANG_NOT_SUPPORTED) {
            AppLog.add("TTS voice missing for " + (if (bn) "Bangla" else "English") + ", reply shudhu screen e dekhabe")
            main.postDelayed({ fire() }, 2500)
            return
        }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { main.post { fire() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { fire() } }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nh")
        val maxWait = minOf(25000L, 4000L + text.length * 130L)
        main.postDelayed({ fire() }, maxWait)
    }

    override fun onDestroy() {
        running = false
        isRunning = false
        main.removeCallbacksAndMessages(null)
        releaseSr()
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        overlay?.removeAll()
        super.onDestroy()
    }
}
