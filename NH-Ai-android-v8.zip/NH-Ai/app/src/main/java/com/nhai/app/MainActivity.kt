package com.nhai.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var orb: OrbView
    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var keyInput: EditText
    private lateinit var chatInput: EditText
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun neon(text: String, color: Int = C.CYAN, click: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(color)
        b.textSize = 13f
        b.background = neonBg(this, color)
        b.setOnClickListener { click() }
        return b
    }

    private fun row(vararg v: android.view.View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (x in v) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), dp(3), dp(3), dp(3))
            r.addView(x, lp)
        }
        return r
    }

    private fun field(hint: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(C.DIM)
        e.setTextColor(C.TEXT)
        e.textSize = 14f
        e.setSingleLine(true)
        e.background = neonBg(this, C.PURPLE, C.CARD, 12)
        e.setPadding(dp(12), dp(10), dp(12), dp(10))
        return e
    }

    private fun buildUi() {
        val sv = ScrollView(this)
        sv.setBackgroundColor(C.BG)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(24), dp(18), dp(24))
        sv.addView(root)

        val title = TextView(this)
        title.text = "NH-AI"
        title.textSize = 30f
        title.typeface = Typeface.DEFAULT_BOLD
        title.letterSpacing = 0.3f
        title.setTextColor(C.CYAN)
        title.gravity = Gravity.CENTER
        root.addView(title)

        val sub = TextView(this)
        sub.text = "YOUR PERSONAL AI ASSISTANT"
        sub.textSize = 11f
        sub.letterSpacing = 0.25f
        sub.setTextColor(C.MAG)
        sub.gravity = Gravity.CENTER
        root.addView(sub)

        orb = OrbView(this)
        val olp = LinearLayout.LayoutParams(dp(210), dp(210))
        olp.gravity = Gravity.CENTER_HORIZONTAL
        olp.topMargin = dp(12)
        root.addView(orb, olp)

        status = TextView(this)
        status.textSize = 13f
        status.setTextColor(C.TEXT)
        status.gravity = Gravity.CENTER
        root.addView(status)

        startBtn = neon("▶  START NH-AI", C.CYAN) { toggleService() }
        startBtn.textSize = 16f
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        slp.topMargin = dp(14)
        root.addView(startBtn, slp)

        root.addView(row(
            neon("1. Permission", C.PURPLE) { askPermissions() },
            neon("2. Overlay", C.PURPLE) { openOverlaySettings() }
        ))
        root.addView(row(
            neon("3. Accessibility", C.PURPLE) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            neon("4. Battery", C.PURPLE) { askBattery() }
        ))

        keyInput = field("Claude API key (sk-ant-...)")
        keyInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        if (Prefs.apiKey(this).isNotEmpty()) keyInput.setText(Prefs.apiKey(this))
        root.addView(row(keyInput, neon("Save", C.MAG) {
            Prefs.setApiKey(this, keyInput.text.toString())
            Toast.makeText(this, "Key saved", Toast.LENGTH_SHORT).show()
        }))
        (keyInput.layoutParams as LinearLayout.LayoutParams).weight = 3f

        // ---- Settings (rebuild chhara change korar jonno) ----
        val setTitle = TextView(this)
        setTitle.text = "SETTINGS"
        setTitle.textSize = 12f
        setTitle.letterSpacing = 0.25f
        setTitle.setTextColor(C.MAG)
        setTitle.setPadding(dp(4), dp(14), 0, dp(2))
        root.addView(setTitle)

        val providerSwitch = Switch(this)
        providerSwitch.text = "Gemini (ফ্রি) ব্যবহার করো — বন্ধ থাকলে Claude"
        providerSwitch.setTextColor(C.TEXT)
        providerSwitch.isChecked = Prefs.provider(this) == "gemini"
        providerSwitch.setPadding(dp(4), dp(8), dp(4), dp(8))
        root.addView(providerSwitch)

        val gemKeyInput = field("Gemini API key (aistudio.google.com)")
        gemKeyInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        if (Prefs.geminiKey(this).isNotEmpty()) gemKeyInput.setText(Prefs.geminiKey(this))
        root.addView(gemKeyInput)

        val gemModelInput = field("Gemini model (default: " + Prefs.DEFAULT_GEMINI_MODEL + ")")
        gemModelInput.setText(Prefs.geminiModel(this))
        root.addView(gemModelInput)

        val modelInput = field("Claude model (default: " + Prefs.DEFAULT_MODEL + ")")
        modelInput.setText(Prefs.model(this))
        val ccInput = field("Country code (BD = 880)")
        ccInput.inputType = InputType.TYPE_CLASS_NUMBER
        ccInput.setText(Prefs.countryCode(this))
        root.addView(row(modelInput, ccInput))
        (modelInput.layoutParams as LinearLayout.LayoutParams).weight = 2f

        val langInput = field("Voice language (bn-BD = বাংলা, en-IN = English)")
        langInput.setText(Prefs.voiceLang(this))
        root.addView(langInput)

        val offLangInput = field("Offline voice language (en-US ba en-IN; Bangla pack thakle bn-BD)")
        offLangInput.setText(Prefs.offlineLang(this))
        root.addView(offLangInput)

        val wakeInput = field("Wake words (comma diye alada)")
        wakeInput.setSingleLine(false)
        wakeInput.setText(Prefs.wakeRaw(this))
        root.addView(wakeInput)

        val looseSwitch = Switch(this)
        looseSwitch.text = "Loose wake: শুধু \"শুনছো / sunco\" শুনলেও জাগবে"
        looseSwitch.setTextColor(C.TEXT)
        looseSwitch.isChecked = Prefs.looseWake(this)
        looseSwitch.setPadding(dp(4), dp(8), dp(4), dp(8))
        root.addView(looseSwitch)

        val directSwitch = Switch(this)
        directSwitch.text = "সরাসরি কল (ডায়ালার ছাড়া)"
        directSwitch.setTextColor(C.TEXT)
        directSwitch.isChecked = Prefs.directCall(this)
        directSwitch.setPadding(dp(4), dp(8), dp(4), dp(8))
        root.addView(directSwitch)

        val offlineSwitch = Switch(this)
        offlineSwitch.text = "Offline-first ভয়েস (ইন্টারনেট থাকলেও আগে অফলাইন)"
        offlineSwitch.setTextColor(C.TEXT)
        offlineSwitch.isChecked = Prefs.offlineFirst(this)
        offlineSwitch.setPadding(dp(4), dp(8), dp(4), dp(8))
        root.addView(offlineSwitch)

        root.addView(row(
            neon("Save settings", C.MAG) {
                Prefs.setModel(this, modelInput.text.toString())
                Prefs.setProvider(this, if (providerSwitch.isChecked) "gemini" else "claude")
                Prefs.setGeminiKey(this, gemKeyInput.text.toString())
                Prefs.setGeminiModel(this, gemModelInput.text.toString())
                Prefs.setCountryCode(this, ccInput.text.toString())
                Prefs.setWake(this, wakeInput.text.toString())
                Prefs.setVoiceLang(this, langInput.text.toString())
                Prefs.setOfflineLang(this, offLangInput.text.toString())
                Prefs.setDirectCall(this, directSwitch.isChecked)
                Prefs.setLooseWake(this, looseSwitch.isChecked)
                Prefs.setOfflineFirst(this, offlineSwitch.isChecked)
                Toast.makeText(this, "Saved ✔ (voice language bodlale STOP -> START koro)", Toast.LENGTH_LONG).show()
            },
            neon("Test popup", C.PURPLE) { testPopup() }
        ))
        root.addView(row(
            neon("Offline voice pack", C.PURPLE) { openVoiceSettings() }
        ))
        root.addView(row(
            neon("Show log", C.PURPLE) { append(AppLog.dump()) },
            neon("Clear log", C.PURPLE) { AppLog.clear(); logView.text = "NH-Ai: log পরিষ্কার" }
        ))

        logView = TextView(this)
        logView.textSize = 14f
        logView.setTextColor(C.TEXT)
        logView.setPadding(dp(10), dp(10), dp(10), dp(10))
        logView.text = "NH-Ai: কী করতে পারি?"
        logScroll = ScrollView(this)
        logScroll.background = neonBg(this, C.CYAN, C.CARD, 12)
        logScroll.addView(logView)
        val llp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(200))
        llp.topMargin = dp(10)
        root.addView(logScroll, llp)

        chatInput = field("লেখো বা বাংলিশে বলো...")
        root.addView(row(chatInput, neon("Send", C.CYAN) { sendTyped() }))
        (chatInput.layoutParams as LinearLayout.LayoutParams).weight = 3f

        setContentView(sv)
    }

    private fun askBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, "Settings > Battery > NH-Ai > Unrestricted", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openVoiceSettings() {
        try {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Google অ্যাপ > Settings > Voice > Offline speech recognition > ভাষা বেছে Download", Toast.LENGTH_LONG).show()
        }
    }

    private fun testPopup() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে 2. Overlay চালু করো", Toast.LENGTH_LONG).show()
            return
        }
        val o = Overlay(this) { }
        o.showPanel("TEST", "Popup ঠিকমতো কাজ করছে।")
        ui.postDelayed({ o.removeAll() }, 3000)
    }

    private fun sendTyped() {
        val t = chatInput.text.toString().trim()
        if (t.isEmpty()) return
        chatInput.setText("")
        append("তুমি: $t")
        val app = applicationContext
        Thread {
            val reply = try {
                CommandRouter.handle(app, t) ?: if (app.isOnline()) Brain.ask(app, t) else OFFLINE_MSG
            } catch (e: Exception) {
                "একটা সমস্যা হয়েছে।"
            }
            runOnUiThread { append("NH-Ai: $reply") }
        }.start()
    }

    private fun append(s: String) {
        logView.append("\n\n" + s)
        logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun askPermissions() {
        val p = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun toggleService() {
        val i = Intent(this, AssistantService::class.java)
        if (AssistantService.isRunning) {
            stopService(i)
        } else {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "আগে 1. Permission চাপো", Toast.LENGTH_LONG).show()
                askPermissions()
                return
            }
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Popup এর জন্য 2. Overlay চালু করো (এখন ছাড়াও চলবে)", Toast.LENGTH_LONG).show()
            }
            ContextCompat.startForegroundService(this, i)
        }
        ui.postDelayed({ refresh() }, 700)
    }

    private fun ck(b: Boolean) = if (b) "✔" else "✘"

    private fun refresh() {
        val mic = granted(Manifest.permission.RECORD_AUDIO)
        val ov = Settings.canDrawOverlays(this)
        val acc = NhAccessibilityService.instance != null
        val run = AssistantService.isRunning
        status.text = "MIC ${ck(mic)}    OVERLAY ${ck(ov)}    ACCESS ${ck(acc)}    NET ${if (isOnline()) "ON" else "OFF"}\n" +
            if (run) "চালু আছে — বলো: \"ai sunco\"" else "বন্ধ আছে"
        startBtn.text = if (run) "■  STOP NH-AI" else "▶  START NH-AI"
        orb.active = run
    }
}
