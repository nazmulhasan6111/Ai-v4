package com.nhai.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApiException(msg: String) : Exception(msg)

object ClaudeClient {
    private val hist = ArrayList<Pair<String, String>>()

    internal fun system(): String =
        "তুমি NH-Ai, Jarvis-এর মতো স্মার্ট পার্সোনাল ভয়েস অ্যাসিস্ট্যান্ট। তুমি ইউজারের Android ফোনে চলছ এবং tool দিয়ে ফোন কন্ট্রোল করতে পারো। " +
        "ফোনের কাজ (অ্যাপ খোলা, কল, মেসেজ, সার্চ, অ্যালার্ম, স্ক্রিনে ক্লিক বা টাইপ ইত্যাদি) করতে হলে অনুমান না করে tool ব্যবহার করো। " +
        "একাধিক ধাপ লাগলে ধাপে ধাপে করো; নতুন অ্যাপ খোলার পর wait দিয়ে তারপর read_screen করো। " +
        "SMS ও WhatsApp শুধু মেসেজ লিখে দেয়, send বাটন ইউজারকে চাপতে হয়, এটা জানিয়ে দাও। " +
        "কাকে কল বা মেসেজ করবে নিশ্চিত না হলে ছোট একটা প্রশ্ন করো এবং প্রশ্নটা ? দিয়ে শেষ করো। " +
        "ইউজার বাংলায় বা বাংলিশে বললে বাংলা হরফে উত্তর দাও, ইংরেজিতে বললে ইংরেজিতে। " +
        "উত্তর ১-৩ ছোট বাক্যে দাও, মার্কডাউন বা ইমোজি বা তালিকা ছাড়া, কারণ উত্তরটা জোরে পড়ে শোনানো হবে। " +
        "এখনকার সময়: " + SimpleDateFormat("EEEE, dd MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())

    private fun msg(role: String, content: String): JSONObject =
        JSONObject().put("role", role).put("content", content)

    @Synchronized
    fun ask(ctx: Context, text: String): String {
        val key = Prefs.apiKey(ctx)
        if (key.isEmpty()) return "আগে অ্যাপের ভেতরে API key সেভ করো।"
        val msgs = JSONArray()
        for (m in hist) msgs.put(msg(m.first, m.second))
        msgs.put(msg("user", text))
        try {
            for (step in 0 until 7) {
                val resp = post(ctx, key, msgs)
                val content = resp.getJSONArray("content")
                if (resp.optString("stop_reason") == "tool_use") {
                    msgs.put(JSONObject().put("role", "assistant").put("content", content))
                    val results = JSONArray()
                    for (i in 0 until content.length()) {
                        val b = content.getJSONObject(i)
                        if (b.optString("type") == "tool_use") {
                            val out = Tools.run(ctx, b.getString("name"), b.optJSONObject("input") ?: JSONObject())
                            results.put(
                                JSONObject()
                                    .put("type", "tool_result")
                                    .put("tool_use_id", b.getString("id"))
                                    .put("content", out.ifEmpty { "ok" })
                            )
                        }
                    }
                    msgs.put(JSONObject().put("role", "user").put("content", results))
                } else {
                    val sb = StringBuilder()
                    for (i in 0 until content.length()) {
                        val o = content.getJSONObject(i)
                        if (o.optString("type") == "text") sb.append(o.optString("text"))
                    }
                    val out = sb.toString().trim().ifEmpty { "হয়ে গেছে।" }
                    remember(text, out)
                    return out
                }
            }
            return "কাজটা শেষ করতে পারলাম না, আবার চেষ্টা করো।"
        } catch (e: ApiException) {
            AppLog.add("api: " + e.message)
            return e.message ?: "API error"
        } catch (e: Exception) {
            AppLog.add("net: " + e)
            return "ইন্টারনেট বা API তে সমস্যা হচ্ছে।"
        }
    }

    private fun remember(user: String, assistant: String) {
        hist.add(Pair("user", user))
        hist.add(Pair("assistant", assistant))
        while (hist.size > 12) hist.removeAt(0)
        while (hist.isNotEmpty() && hist[0].first != "user") hist.removeAt(0)
    }

    private fun post(ctx: Context, key: String, msgs: JSONArray): JSONObject {
        val body = JSONObject()
            .put("model", Prefs.model(ctx))
            .put("max_tokens", 600)
            .put("system", system())
            .put("tools", Tools.defs)
            .put("messages", msgs)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", key)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                if (code == 401) throw ApiException("API key ভুল মনে হচ্ছে।")
                throw ApiException("API error $code: " + resp.take(140))
            }
            return JSONObject(resp)
        } finally {
            c.disconnect()
        }
    }
}
