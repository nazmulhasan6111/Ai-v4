# NH-Ai (Android) v3 (offline + online)

"ai sunco" bolle background e jage -> command shuney Claude (tool-use) diye phone chalay. Onno app er upor popup + floating orb.

## APK banano (GitHub Actions)
1. GitHub repo te shob file upload koro (.github folder shoho).
2. Actions -> "Build APK" -> Run workflow. Shesh hole Artifacts theke NH-Ai-APK nao.

## Prothom bar setup
1. Permission  2. Overlay  3. Accessibility  4. Battery (Unrestricted)
5. Claude API key paste -> Save,  6. START NH-AI,  7. bolo: "ai sunco"

## Rebuild chhara ja change kora jay (app er SETTINGS section)
- Wake words (recognizer bhul shunle notun variant likho; "Show log" e dekho ki shunlo)
- Model naam, country code (WhatsApp number er jonno), sorasori call on/off
- Test popup, log dekha

## Claude je tool gulo chalate pare
open_app, call, send_sms, send_whatsapp, read_screen, click, type_text, scroll, press (home/back/recents/notifications/lock/screenshot/power),
set_alarm, set_timer, torch, set_volume, media, open_url, web_search, youtube_search, navigate, open_settings, battery, current_time, wait

Example: "রহিমকে হোয়াটসঅ্যাপে লেখো আমি আসছি", "ইউটিউবে বাংলা গান সার্চ করো", "স্ক্রিনে কী লেখা আছে পড়ে শোনাও",
"৫ মিনিটের টাইমার দাও", "নেভিগেট করো ঢাকা মেডিকেল", "স্ক্রিনশট নাও", "গান পরেরটা দাও"

## Offline / Online
- Internet nai: NH-Ai local command gulo kore (app khola, call, torch, volume, alarm, battery, gaan control, screenshot, lock, home/back/click/scroll).
  Onno proshno hole bole "ইন্টারনেট নেই".
- Internet ache: shob kichu Claude (tool-use) diye.
- Offline voice shona: phone e Google er Bangla offline pack download thaka lagbe
  (app e "Offline voice pack" chapo -> Offline speech recognition -> বাংলা).
  Pack na thakle ar internet na thakle app boley dibe.
- Offline kotha bola (TTS): phone er Settings > Text-to-speech e Bangla voice data install thakte hobe.
- "Offline-first" switch on korle internet thakleo age offline recognizer cholbe (battery o data bachay).

## v4: Free Gemini API
- aistudio.google.com -> Get API key -> Create API key (credit card lage na, free tier ache).
- App e Settings: "Gemini (ফ্রি)" switch ON, Gemini API key paste, Save settings, tarpor STOP -> START.
- Model default: gemini-flash-latest. 404 error hole Settings e Gemini model naam thik koro.
- Free tier e rate limit ache; limit shesh hole app bolbe. Free tier e pathano kotha Google nijer product bhalo korte use korte pare.

## v5: speed + stability
- Gemini thinking mode off (reply fast), busy (503) hole auto retry, slow net hole alada message.
- Aro fast korte: Settings e Gemini model = gemini-flash-lite-latest (404 dile gemini-flash-latest e ferot jao).

## v6: full review fixes
- Chat prosner shathe command mile jaoa bondho (lomba kotha shorashori AI te jay; home/back/wifi ityadi shudhu choto command hole).
- App khola ekhon shobdo diye (jemon "খুলনা" te bhul hoy na); app na pele AI uttor dey.
- TTS: Android 11+ er jonno missing declaration jog kora hoyeche; Bangla voice na thakle screen e uttor dekhay.
- Voice language Settings e (bn-BD / en-IN), battery optimization direct dialog, rotate korle log haray na.

## v7: offline voice
- Offline er jonno alada bhasha (Settings: Offline voice language, default en-US). Internet nai hole ba Offline-first on hole eta use hoy.
- Pack download: Google app > Settings > Voice > Offline speech recognition (ba Settings > System > Languages > Gboard > Voice typing > Offline speech recognition) > English > Download.
- Offline e Banglish/English command bolo: "open youtube", "torch on", "volume barao", "call rahim", "youtube kholo".
- Bangla offline pack na pele chat box e likhe command dao (shob offline command kaj kore).

## v8: wake word fix
- Recognizer ekhon bar bar notun kore na banay (kotha miss kom), nije atke gele watchdog abar chalu kore.
- Fuzzy match: "এই শুনছো", "ai shuncho", "hi sunco" shob ekei dhoray; Loose wake switch (default ON) shudhu "শুনছো/sunco" shunleo jagay.
- Notification e "🎙 বলো" button: wake word chhara-o ek tap e command neya shuru.
- "Show log" e partial: ar heard[WAKE]: line dekhe bojha jay recognizer ki shunche.
